> Note: The packaged `data/Claimdata.csv` is a sample claim-resolution dataset so the pipeline runs immediately. Replace it with your actual file before production training.

# Claim Resolution Enterprise ML Pipeline

Production-style Python ML pipeline for training a claim resolution prediction model from `Claimdata.csv`.

## Included
- Data ingestion
- Data validation
- Automated EDA summary
- Preprocessing pipeline
- Model comparison automation
- Hyperparameter tuning
- Feature importance export
- Logging
- Custom exception handling
- FastAPI prediction API
- `.exe` build support using PyInstaller
- Config-driven project

## Dataset
The uploaded dataset contains these columns:
- Claim_ID
- Policy_Type
- Hospital_Type
- Claim_Amount
- Diagnosis
- City
- Age
- Gender
- Days_Hospitalized
- Resolution

Target:
- `Resolution` with classes such as `Approved`, `Rejected`, `Pending`

## Installation

```bash
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
```

## Train the model

```bash
python train.py
```

Artifacts are saved under `artifacts/`.

## Run API

```bash
uvicorn app:app --reload
```

Swagger:
- http://127.0.0.1:8000/docs

## Example request

```json
{
  "Policy_Type": "Corporate",
  "Hospital_Type": "Private",
  "Claim_Amount": 45000,
  "Diagnosis": "Cardiology",
  "City": "Hyderabad",
  "Age": 45,
  "Gender": "Male",
  "Days_Hospitalized": 4
}
```

## Build EXE

```bash
pyinstaller --onefile --name claim_api_runner run_api.py
```

For a prediction-only executable:

```bash
pyinstaller --onefile --name claim_predict_cli predict_cli.py
```

## Files
- `train.py` → full training run
- `app.py` → FastAPI app
- `run_api.py` → API launcher
- `predict_cli.py` → CLI prediction utility
- `config.yaml` → project configuration


## Optional boosters

XGBoost and LightGBM are included in `requirements.txt`. Default training keeps them disabled for maximum compatibility. To experiment with them, set `include_optional_boosters: true` in `config.yaml`.
