import pandas as pd
from src.utils.common import read_yaml

if __name__ == "__main__":
    config = read_yaml("config.yaml")
    df = pd.read_csv(config["data"]["raw_data_path"])
    print("Shape:", df.shape)
    print("\nColumns:", list(df.columns))
    print("\nMissing values:\n", df.isna().sum())
    print("\nTarget distribution:\n", df[config["data"]["target_column"]].value_counts())
