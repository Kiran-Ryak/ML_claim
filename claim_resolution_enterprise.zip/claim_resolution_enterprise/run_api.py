import uvicorn
from src.utils.common import read_yaml

if __name__ == "__main__":
    config = read_yaml("config.yaml")
    uvicorn.run("app:app", host=config["api"]["host"], port=config["api"]["port"], reload=False)
