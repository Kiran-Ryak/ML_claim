import argparse
import json
from src.pipeline.predict_pipeline import PredictPipeline


def main():
    parser = argparse.ArgumentParser(description="Claim resolution prediction CLI")
    parser.add_argument("--input_json", required=True, help="JSON string with model input fields")
    args = parser.parse_args()

    predictor = PredictPipeline(config_path="config.yaml")
    payload = json.loads(args.input_json)
    result = predictor.predict(payload)
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
