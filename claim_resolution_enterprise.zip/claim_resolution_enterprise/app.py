from fastapi import FastAPI
from pydantic import BaseModel, Field
from typing import Dict, Any

from src.pipeline.predict_pipeline import PredictPipeline

app = FastAPI(title="Claim Resolution Prediction API", version="1.0.0")
predictor = PredictPipeline(config_path="config.yaml")


class ClaimInput(BaseModel):
    Policy_Type: str = Field(..., examples=["Corporate"])
    Hospital_Type: str = Field(..., examples=["Private"])
    Claim_Amount: float = Field(..., examples=[45000])
    Diagnosis: str = Field(..., examples=["Cardiology"])
    City: str = Field(..., examples=["Hyderabad"])
    Age: int = Field(..., examples=[45])
    Gender: str = Field(..., examples=["Male"])
    Days_Hospitalized: int = Field(..., examples=[4])


@app.get("/")
def home() -> Dict[str, str]:
    return {"message": "Claim Resolution Prediction API is running"}


@app.get("/health")
def health() -> Dict[str, str]:
    return {"status": "ok"}


@app.post("/predict")
def predict(data: ClaimInput) -> Dict[str, Any]:
    result = predictor.predict(data.model_dump())
    return result
