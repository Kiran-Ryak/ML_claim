from src.pipeline.train_pipeline import TrainPipeline

if __name__ == "__main__":
    trainer = TrainPipeline(config_path="config.yaml")
    trainer.run()
