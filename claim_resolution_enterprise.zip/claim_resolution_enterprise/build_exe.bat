@echo off
echo Building API executable...
pyinstaller --onefile --name claim_api_runner run_api.py

echo Building prediction CLI executable...
pyinstaller --onefile --name claim_predict_cli predict_cli.py

echo Build completed.
pause
