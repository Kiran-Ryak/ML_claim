# Automated EDA Report
- Rows: **60**
- Columns: **10**

## Target Distribution
- Pending: 35
- Approved: 15
- Rejected: 10

## Missing Values
- Claim_ID: 0
- Policy_Type: 0
- Hospital_Type: 0
- Claim_Amount: 0
- Diagnosis: 0
- City: 0
- Age: 0
- Gender: 0
- Days_Hospitalized: 0
- Resolution: 0

## Categorical Cardinality
- Claim_ID: 60
- Policy_Type: 3
- Hospital_Type: 3
- Diagnosis: 5
- City: 5
- Gender: 2
- Resolution: 3