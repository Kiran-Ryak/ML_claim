from __future__ import annotations

from typing import Dict, Any
import pandas as pd

from src.exception import CustomException
from src.logger import get_logger
from src.utils.common import read_yaml, load_object, load_json

logger = get_logger(__name__)


class PredictPipeline:
    def __init__(self, config_path: str):
        self.config = read_yaml(config_path)
        self.model = load_object(self.config["artifacts"]["model_path"])
        self.metadata = load_json(self.config["artifacts"]["best_model_metadata_path"])

    def predict(self, data: Dict[str, Any]) -> Dict[str, Any]:
        try:
            df = pd.DataFrame([data])
            prediction = self.model.predict(df)[0]
            response: Dict[str, Any] = {
                "prediction": str(prediction),
                "best_model_name": self.metadata.get("best_model_name"),
            }

            if hasattr(self.model, "predict_proba"):
                proba = self.model.predict_proba(df)[0]
                classes = [str(c) for c in self.model.classes_]
                class_probabilities = {
                    cls: round(float(prob), 4)
                    for cls, prob in zip(classes, proba)
                }
                response["class_probabilities"] = class_probabilities

            logger.info("Prediction generated successfully")
            return response
        except Exception as e:
            raise CustomException(e)
