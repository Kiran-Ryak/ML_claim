from __future__ import annotations

import os

from sklearn.model_selection import train_test_split

from src.components.data_ingestion import DataIngestion
from src.components.data_validation import DataValidation
from src.components.eda import EDAReport
from src.components.data_transformation import DataTransformation
from src.components.model_trainer import ModelTrainer
from src.exception import CustomException
from src.logger import get_logger
from src.utils.common import read_yaml, save_object, save_json

logger = get_logger(__name__)


class TrainPipeline:
    def __init__(self, config_path: str):
        self.config = read_yaml(config_path)
        self.config_path = config_path

    def run(self) -> None:
        try:
            logger.info("Training pipeline started")
            cfg = self.config
            os.makedirs(cfg["artifacts"]["root_dir"], exist_ok=True)

            ingestion = DataIngestion(cfg["data"]["raw_data_path"])
            df = ingestion.read_data()

            validator = DataValidation(cfg["schema"])
            validator.validate(df)

            eda = EDAReport(
                cfg["artifacts"]["eda_summary_path"],
                cfg["artifacts"]["eda_markdown_path"],
            )
            eda.generate(df, cfg["data"]["target_column"])

            transformer = DataTransformation(
                numeric_columns=cfg["schema"]["numeric_columns"],
                categorical_columns=cfg["schema"]["categorical_columns"],
            )

            X, y = transformer.split_features_target(
                df=df,
                target_column=cfg["data"]["target_column"],
                drop_columns=cfg["data"]["drop_columns"],
            )
            preprocessor = transformer.get_preprocessor()

            X_train, X_test, y_train, y_test = train_test_split(
                X,
                y,
                train_size=cfg["data"]["train_size"],
                random_state=cfg["data"]["random_state"],
                stratify=y,
            )

            trainer = ModelTrainer(
                preprocessor=preprocessor,
                random_state=cfg["data"]["random_state"],
                include_optional_boosters=cfg["data"].get("include_optional_boosters", False),
                metrics_path=cfg["artifacts"]["metrics_path"],
                metadata_path=cfg["artifacts"]["best_model_metadata_path"],
                feature_importance_path=cfg["artifacts"]["feature_importance_path"],
            )

            model, metadata, feature_importance_df = trainer.train_and_select(
                X_train=X_train,
                X_test=X_test,
                y_train=y_train,
                y_test=y_test,
            )

            save_object(cfg["artifacts"]["model_path"], model)

            train_pred = model.predict(X_train)
            test_pred = model.predict(X_test)

            train_output = X_train.copy()
            train_output["actual"] = y_train.values
            train_output["predicted"] = train_pred
            train_output.to_csv(cfg["artifacts"]["train_predictions_path"], index=False)

            test_output = X_test.copy()
            test_output["actual"] = y_test.values
            test_output["predicted"] = test_pred
            test_output.to_csv(cfg["artifacts"]["test_predictions_path"], index=False)

            save_json(
                cfg["artifacts"]["label_classes_path"],
                {"classes": sorted(df[cfg["data"]["target_column"]].astype(str).unique().tolist())},
            )

            print("Training completed successfully.")
            print(f"Best model: {metadata['best_model_name']}")
            print(f"Best test weighted F1: {metadata['best_test_f1_weighted']}")
            print("Top 10 important features:")
            print(feature_importance_df.head(10).to_string(index=False))

            logger.info("Training pipeline completed")
        except Exception as e:
            raise CustomException(e)
