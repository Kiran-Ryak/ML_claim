from __future__ import annotations

from typing import Tuple, List

import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

from src.exception import CustomException
from src.logger import get_logger

logger = get_logger(__name__)


class DataTransformation:
    def __init__(self, numeric_columns: List[str], categorical_columns: List[str]):
        self.numeric_columns = numeric_columns
        self.categorical_columns = categorical_columns

    def get_preprocessor(self) -> ColumnTransformer:
        try:
            numeric_pipeline = Pipeline(
                steps=[
                    ("imputer", SimpleImputer(strategy="median")),
                    ("scaler", StandardScaler()),
                ]
            )

            categorical_pipeline = Pipeline(
                steps=[
                    ("imputer", SimpleImputer(strategy="most_frequent")),
                    ("onehot", OneHotEncoder(handle_unknown="ignore")),
                ]
            )

            preprocessor = ColumnTransformer(
                transformers=[
                    ("num", numeric_pipeline, self.numeric_columns),
                    ("cat", categorical_pipeline, self.categorical_columns),
                ]
            )
            return preprocessor
        except Exception as e:
            raise CustomException(e)

    def split_features_target(
        self,
        df: pd.DataFrame,
        target_column: str,
        drop_columns: list[str],
    ) -> Tuple[pd.DataFrame, pd.Series]:
        try:
            X = df.drop(columns=[target_column] + drop_columns)
            y = df[target_column]
            logger.info("Prepared X and y with shapes %s and %s", X.shape, y.shape)
            return X, y
        except Exception as e:
            raise CustomException(e)
