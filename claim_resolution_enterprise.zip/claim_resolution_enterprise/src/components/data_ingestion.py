import pandas as pd

from src.exception import CustomException
from src.logger import get_logger

logger = get_logger(__name__)


class DataIngestion:
    def __init__(self, raw_data_path: str):
        self.raw_data_path = raw_data_path

    def read_data(self) -> pd.DataFrame:
        try:
            logger.info("Reading raw data from %s", self.raw_data_path)
            df = pd.read_csv(self.raw_data_path)
            logger.info("Data shape loaded: %s", df.shape)
            return df
        except Exception as e:
            raise CustomException(e)
