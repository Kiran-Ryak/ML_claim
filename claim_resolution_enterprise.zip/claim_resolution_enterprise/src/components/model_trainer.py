from __future__ import annotations

import warnings
from typing import Dict, Any

import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier, ExtraTreesClassifier, GradientBoostingClassifier
from sklearn.linear_model import LogisticRegression

from sklearn.base import BaseEstimator, ClassifierMixin, clone
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import accuracy_score, f1_score, classification_report
from sklearn.model_selection import RandomizedSearchCV
from sklearn.pipeline import Pipeline
from sklearn.compose import ColumnTransformer

from src.exception import CustomException
from src.logger import get_logger
from src.utils.common import save_json

logger = get_logger(__name__)
warnings.filterwarnings("ignore")

try:
    from xgboost import XGBClassifier
    XGBOOST_AVAILABLE = True
except Exception:
    XGBOOST_AVAILABLE = False

try:
    from lightgbm import LGBMClassifier
    LIGHTGBM_AVAILABLE = True
except Exception:
    LIGHTGBM_AVAILABLE = False




class EncodedTargetClassifier(BaseEstimator, ClassifierMixin):
    def __init__(self, estimator):
        self.estimator = estimator

    def fit(self, X, y):
        self.label_encoder_ = LabelEncoder()
        y_encoded = self.label_encoder_.fit_transform(y)
        self.estimator_ = clone(self.estimator)
        self.estimator_.fit(X, y_encoded)
        self.classes_ = self.label_encoder_.classes_
        return self

    def predict(self, X):
        pred = self.estimator_.predict(X)
        return self.label_encoder_.inverse_transform(pred.astype(int))

    def predict_proba(self, X):
        return self.estimator_.predict_proba(X)

    def get_params(self, deep=True):
        return {"estimator": self.estimator}

    def set_params(self, **params):
        if "estimator" in params:
            self.estimator = params["estimator"]
        return self


class ModelTrainer:
    def __init__(
        self,
        preprocessor: ColumnTransformer,
        random_state: int,
        include_optional_boosters: bool,
        metrics_path: str,
        metadata_path: str,
        feature_importance_path: str,
    ):
        self.preprocessor = preprocessor
        self.random_state = random_state
        self.include_optional_boosters = include_optional_boosters
        self.metrics_path = metrics_path
        self.metadata_path = metadata_path
        self.feature_importance_path = feature_importance_path

    def _build_models(self) -> Dict[str, tuple[Pipeline, dict]]:
        models: Dict[str, tuple[Pipeline, dict]] = {
            "logistic_regression": (
                Pipeline(
                    steps=[
                        ("preprocessor", self.preprocessor),
                        ("model", LogisticRegression(max_iter=1000, random_state=self.random_state)),
                    ]
                ),
                {
                    "model__C": np.logspace(-2, 1, 10),
                    "model__solver": ["lbfgs", "liblinear"],
                },
            ),
            "random_forest": (
                Pipeline(
                    steps=[
                        ("preprocessor", self.preprocessor),
                        ("model", RandomForestClassifier(random_state=self.random_state)),
                    ]
                ),
                {
                    "model__n_estimators": [50, 100, 150, 200],
                    "model__max_depth": [None, 3, 5, 8, 12],
                    "model__min_samples_split": [2, 4, 6],
                },
            ),
            "extra_trees": (
                Pipeline(
                    steps=[
                        ("preprocessor", self.preprocessor),
                        ("model", ExtraTreesClassifier(random_state=self.random_state)),
                    ]
                ),
                {
                    "model__n_estimators": [50, 100, 150, 200],
                    "model__max_depth": [None, 3, 5, 8, 12],
                    "model__min_samples_split": [2, 4, 6],
                },
            ),
            "gradient_boosting": (
                Pipeline(
                    steps=[
                        ("preprocessor", self.preprocessor),
                        ("model", GradientBoostingClassifier(random_state=self.random_state)),
                    ]
                ),
                {
                    "model__n_estimators": [50, 100, 150],
                    "model__learning_rate": [0.01, 0.05, 0.1, 0.2],
                    "model__max_depth": [2, 3, 4],
                },
            ),
        }

        if self.include_optional_boosters and XGBOOST_AVAILABLE:
            models["xgboost"] = (
                Pipeline(
                    steps=[
                        ("preprocessor", self.preprocessor),
                        ("model", EncodedTargetClassifier(XGBClassifier(
                            random_state=self.random_state,
                            eval_metric="mlogloss",
                            objective="multi:softprob",
                            num_class=3,
                        ))),
                    ]
                ),
                {
                    "model__estimator__n_estimators": [50, 100, 150],
                    "model__estimator__max_depth": [3, 4, 5, 6],
                    "model__estimator__learning_rate": [0.03, 0.05, 0.1],
                    "model__estimator__subsample": [0.7, 0.9, 1.0],
                },
            )

        if self.include_optional_boosters and LIGHTGBM_AVAILABLE:
            models["lightgbm"] = (
                Pipeline(
                    steps=[
                        ("preprocessor", self.preprocessor),
                        ("model", EncodedTargetClassifier(LGBMClassifier(random_state=self.random_state, verbose=-1))),
                    ]
                ),
                {
                    "model__estimator__n_estimators": [50, 100, 150],
                    "model__estimator__learning_rate": [0.03, 0.05, 0.1],
                    "model__estimator__num_leaves": [15, 31, 63],
                },
            )

        return models

    def train_and_select(
        self,
        X_train: pd.DataFrame,
        X_test: pd.DataFrame,
        y_train: pd.Series,
        y_test: pd.Series,
    ) -> tuple[Pipeline, Dict[str, Any], pd.DataFrame]:
        try:
            models = self._build_models()
            metrics_summary: Dict[str, Any] = {}
            best_model = None
            best_score = -1.0
            best_name = None
            best_search_params = {}

            for name, (pipeline, param_grid) in models.items():
                logger.info("Tuning model: %s", name)
                search = RandomizedSearchCV(
                    estimator=pipeline,
                    param_distributions=param_grid,
                    n_iter=min(8, max(3, len(list(param_grid.keys())) * 2)),
                    scoring="f1_weighted",
                    cv=3,
                    random_state=self.random_state,
                    n_jobs=1,
                )
                search.fit(X_train, y_train)

                y_pred = search.best_estimator_.predict(X_test)
                accuracy = accuracy_score(y_test, y_pred)
                f1_weighted = f1_score(y_test, y_pred, average="weighted")

                metrics_summary[name] = {
                    "best_params": search.best_params_,
                    "cv_best_score_f1_weighted": round(float(search.best_score_), 4),
                    "test_accuracy": round(float(accuracy), 4),
                    "test_f1_weighted": round(float(f1_weighted), 4),
                    "classification_report": classification_report(y_test, y_pred, output_dict=True),
                }

                if f1_weighted > best_score:
                    best_score = f1_weighted
                    best_model = search.best_estimator_
                    best_name = name
                    best_search_params = search.best_params_

            save_json(self.metrics_path, metrics_summary)

            metadata = {
                "best_model_name": best_name,
                "selection_metric": "test_f1_weighted",
                "best_test_f1_weighted": round(float(best_score), 4),
                "best_params": best_search_params,
                "xgboost_available": XGBOOST_AVAILABLE,
                "lightgbm_available": LIGHTGBM_AVAILABLE,
            }
            save_json(self.metadata_path, metadata)

            feature_importance_df = self._extract_feature_importance(best_model)
            feature_importance_df.to_csv(self.feature_importance_path, index=False)

            return best_model, metadata, feature_importance_df
        except Exception as e:
            raise CustomException(e)

    def _extract_feature_importance(self, fitted_pipeline: Pipeline) -> pd.DataFrame:
        try:
            preprocessor = fitted_pipeline.named_steps["preprocessor"]
            model = fitted_pipeline.named_steps["model"]
            feature_names = preprocessor.get_feature_names_out()

            if hasattr(model, "feature_importances_"):
                values = model.feature_importances_
            elif hasattr(model, "coef_"):
                coef = model.coef_
                values = np.mean(np.abs(coef), axis=0) if coef.ndim > 1 else np.abs(coef)
            else:
                values = np.zeros(len(feature_names))

            fi = pd.DataFrame({"feature": feature_names, "importance": values})
            fi = fi.sort_values("importance", ascending=False).reset_index(drop=True)
            return fi
        except Exception as e:
            raise CustomException(e)
