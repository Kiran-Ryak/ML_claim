from __future__ import annotations

import pandas as pd
import numpy as np

from src.exception import CustomException
from src.logger import get_logger
from src.utils.common import save_json

logger = get_logger(__name__)


class EDAReport:
    def __init__(self, eda_json_path: str, eda_markdown_path: str):
        self.eda_json_path = eda_json_path
        self.eda_markdown_path = eda_markdown_path

    def generate(self, df: pd.DataFrame, target_column: str) -> None:
        try:
            logger.info("Generating EDA summary")
            summary = {
                "shape": {"rows": int(df.shape[0]), "columns": int(df.shape[1])},
                "columns": list(df.columns),
                "dtypes": {col: str(dtype) for col, dtype in df.dtypes.items()},
                "missing_values": df.isna().sum().to_dict(),
                "missing_percentage": ((df.isna().mean() * 100).round(2)).to_dict(),
                "target_distribution": df[target_column].value_counts(dropna=False).to_dict(),
                "numeric_summary": df.describe(include=[np.number]).round(2).to_dict(),
                "categorical_cardinality": {
                    col: int(df[col].nunique(dropna=True))
                    for col in df.select_dtypes(include=["object", "category"]).columns
                },
            }
            save_json(self.eda_json_path, summary)

            md = []
            md.append("# Automated EDA Report")
            md.append(f"- Rows: **{df.shape[0]}**")
            md.append(f"- Columns: **{df.shape[1]}**")
            md.append("")
            md.append("## Target Distribution")
            for k, v in summary["target_distribution"].items():
                md.append(f"- {k}: {v}")
            md.append("")
            md.append("## Missing Values")
            for col, val in summary["missing_values"].items():
                md.append(f"- {col}: {val}")
            md.append("")
            md.append("## Categorical Cardinality")
            for col, val in summary["categorical_cardinality"].items():
                md.append(f"- {col}: {val}")
            with open(self.eda_markdown_path, "w", encoding="utf-8") as f:
                f.write("\n".join(md))
            logger.info("EDA summary saved")
        except Exception as e:
            raise CustomException(e)
