import pandas as pd

from src.exception import CustomException
from src.logger import get_logger

logger = get_logger(__name__)


class DataValidation:
    def __init__(self, schema_config: dict):
        self.schema_config = schema_config

    def validate(self, df: pd.DataFrame) -> None:
        try:
            logger.info("Starting data validation")
            required_columns = self.schema_config["required_columns"]
            missing_columns = [col for col in required_columns if col not in df.columns]
            if missing_columns:
                raise ValueError(f"Missing required columns: {missing_columns}")

            numeric_columns = self.schema_config["numeric_columns"]
            for col in numeric_columns:
                if not pd.api.types.is_numeric_dtype(df[col]):
                    raise TypeError(f"Column '{col}' must be numeric")

            target_values = set(self.schema_config["allowed_target_values"])
            actual_values = set(df["Resolution"].dropna().unique())
            unknown_values = actual_values - target_values
            if unknown_values:
                raise ValueError(f"Unexpected target values found: {unknown_values}")

            if df.empty:
                raise ValueError("Input dataframe is empty")

            logger.info("Data validation completed successfully")
        except Exception as e:
            raise CustomException(e)
