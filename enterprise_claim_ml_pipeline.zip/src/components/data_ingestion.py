
import pandas as pd

class DataIngestion:

    def load_data(self, path):
        df = pd.read_csv(path)
        df.columns = [c.strip() for c in df.columns]
        return df
