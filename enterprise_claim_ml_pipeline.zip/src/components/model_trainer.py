
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, classification_report
from sklearn.pipeline import Pipeline
from sklearn.ensemble import RandomForestClassifier
from xgboost import XGBClassifier

from src.utils.utils import save_object

class ModelTrainer:

    def train(self, X, y, preprocessor):

        models = {
            "random_forest": RandomForestClassifier(),
            "xgboost": XGBClassifier(eval_metric="logloss")
        }

        best_score = 0
        best_pipeline = None

        for name, model in models.items():

            pipeline = Pipeline([
                ("preprocessor", preprocessor),
                ("model", model)
            ])

            X_train, X_test, y_train, y_test = train_test_split(
                X, y, test_size=0.2, random_state=42
            )

            pipeline.fit(X_train, y_train)

            preds = pipeline.predict(X_test)

            score = accuracy_score(y_test, preds)

            print(name, "Accuracy:", score)

            if score > best_score:
                best_score = score
                best_pipeline = pipeline

        save_object("artifacts/model.pkl", best_pipeline)

        print("Best model saved")
