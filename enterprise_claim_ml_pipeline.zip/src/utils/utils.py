
import os, joblib

def save_object(path, obj):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    joblib.dump(obj, path)

def load_object(path):
    return joblib.load(path)
