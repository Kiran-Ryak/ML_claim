
import pandas as pd
from src.utils.utils import load_object

class PredictPipeline:

    def __init__(self):
        self.model = load_object("artifacts/model.pkl")

    def predict(self, data):

        df = pd.DataFrame([data])

        pred = self.model.predict(df)

        return {"Resolution Prediction": str(pred[0])}
