
from src.components.data_ingestion import DataIngestion
from src.components.data_transformation import DataTransformation
from src.components.model_trainer import ModelTrainer

class TrainPipeline:

    def run_pipeline(self, file_path):

        ingestion = DataIngestion()
        df = ingestion.load_data(file_path)

        target = "Resolution"

        X = df.drop(columns=[target])
        y = df[target]

        transformer = DataTransformation()
        preprocessor = transformer.transform(X)

        trainer = ModelTrainer()
        trainer.train(X, y, preprocessor)
