
from fastapi import FastAPI
from pydantic import BaseModel
from typing import Dict, Any
from src.pipeline.predict_pipeline import PredictPipeline

app = FastAPI(title="Enterprise Claim Resolution API")
predictor = PredictPipeline()

class ClaimInput(BaseModel):
    data: Dict[str, Any]

@app.get("/")
def home():
    return {"message": "Enterprise Claim Resolution API Running"}

@app.post("/predict")
def predict(data: ClaimInput):
    result = predictor.predict(data.data)
    return result
